x=input('x:')
y=input('y:')
print(x+y)
