name='鱼嘉诚'
age=18
address='西安市'
print('个人信息：姓名：%s 年龄：%.2f 地址：%s' % (name,age,address))