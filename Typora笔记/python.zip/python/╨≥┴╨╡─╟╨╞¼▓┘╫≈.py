"""语法：序列[起始下标：结束下标(不包含)：步长]"""
#对list进行切片
my_list=[0,1,2,3,4,5,6,7,8,9]
print(my_list[1:4:1])

#对tuple进行切片
my_tuple=(0,1,2,3,4,5)
print(my_tuple[1:4:1])

#对str进行切片
my_str='yu ji ac eng'
print(my_str[0:10:2])
