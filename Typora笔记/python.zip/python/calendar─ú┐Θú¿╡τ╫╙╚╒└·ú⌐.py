#电子日历
import calendar
calendar.month(2024,3)
print('--------------------')
print(calendar.month(2017,3))
print('--------------------')

print(calendar.prcal(2024))

