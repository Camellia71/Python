import datetime as Date
today=Date.date.today()
now=Date.datetime.now()
print('今日日期：',end='')
print(today)
print('当前时间：',end='')
print(now)





