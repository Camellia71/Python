import random
for i in range(9):
    a = random.randint(1, 100)
    print(a,end=' ')
