def swap(a,b):
    return b,a
a,b=input().split( )
a,b=int(a),int(b)
print(swap(a,b))
