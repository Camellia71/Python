#第一种安装方式
"""
1.打开windows键
2.搜索cmd
3.输入"pip install [包的名称]"
"""
#此方式连接的是国外网站，下载速度较慢

#第二种安装方式
"""
1.打开windows键
2.搜索cmd
3.输入"pip install -i https://pypi.tuna.tsinghua.edu.cn/simple [包的名称]"
"""
#使用国内网站下载，下载时速度快

#第三种安装方式（pycharm安装）
"""
1.点击pycharm右下角解释器
2.点击interpreter settings
3.点击+
"""