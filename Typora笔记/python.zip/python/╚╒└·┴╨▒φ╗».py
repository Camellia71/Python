import calendar
calendar.monthcalendar(2024,12)
print(calendar.monthcalendar(2024,12))
