import calendar
#某年某月从周几开始，一共有多少天
print(calendar.monthrange(2024,12))
#计算某天是周几
print(calendar.weekday(2018,8,15))